#pragma once

#include <string>
#include "Constantes.h"
using namespace std;

void verifierNombreDonner(double&);
void verifierNombreZeroDivision(double);
void verifierSerieTaylorN(double&);