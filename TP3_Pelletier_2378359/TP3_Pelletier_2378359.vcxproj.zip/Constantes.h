#pragma once

enum Operation
{
	Addition = '+',
	Soustraction = '-',
	Multiplication = '*',
	Division = '/',
	Exposant = '^',
	Factorielle = '!',
	SerieDeTaylor = 's',
	Rectangle = 'r',
	Triangle = 't',
	Quitter = 'q',
	Diviseurs = 'd',
	NombrePremier = 'p',
	Inverser = 'i',
	Transformer = 'b',
	Seed = 'c',
	LancerDes = 'l',
	Aleatoire = 'a',

};
