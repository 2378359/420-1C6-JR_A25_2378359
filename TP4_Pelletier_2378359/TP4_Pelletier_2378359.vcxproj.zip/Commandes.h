#pragma once
#include <string>

using namespace std;

string verifierCommande(string& commandeDonner, const string& prompt);